package business;
public interface IShape 
{
	public void draw();
	public void translate();
	public String getStartPoint();
}
