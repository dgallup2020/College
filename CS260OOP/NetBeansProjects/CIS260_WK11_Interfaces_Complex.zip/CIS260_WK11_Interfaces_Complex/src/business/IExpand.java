package business;

public interface IExpand {
	public void expand();

}
