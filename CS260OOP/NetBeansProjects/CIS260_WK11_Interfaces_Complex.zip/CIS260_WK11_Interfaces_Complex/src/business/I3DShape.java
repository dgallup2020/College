package business;

public interface I3DShape {
	public double volume();
}
