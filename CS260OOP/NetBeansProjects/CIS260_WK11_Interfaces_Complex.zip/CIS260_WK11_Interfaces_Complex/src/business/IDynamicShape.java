package business;

public interface IDynamicShape {
	public void rotate();
}
