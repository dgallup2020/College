/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;
/**
 *
 * @author dgallup14
 */
public class Standard_Benefits extends Benefits{

    public Standard_Benefits() {
        super(BenefitsTypes.BenefitPackages.STANDARD);
    }  
}
